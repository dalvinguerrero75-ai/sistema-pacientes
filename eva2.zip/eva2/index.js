// index.js

// 1. Importar las herramientas (dependencias)
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

// 2. Crear la aplicación (el servidor)
const app = express();
const port = 3000;

// 3. Configurar los permisos (Middleware)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());

// (Aquí debes tener la lógica para manejar las rutas)
const pacienteRoutes = require('./routes/pacienteRoutes');
app.use('/api', pacienteRoutes);

// 4. Conectar a MongoDB
mongoose.connect('mongodb://localhost:27017/hospitalDB')
  .then(() => console.log('Conexión exitosa a MongoDB'))
  .catch(err => console.error('Error al conectar a MongoDB', err));

// 5. Encender el servidor
app.listen(port, () => {
  console.log(`Servidor escuchando en http://localhost:${port}`);
});