// models/Paciente.js

const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Definimos el "molde" (Schema) de nuestro paciente
const PacienteSchema = new Schema({
    rut: { type: String, required: true, unique: true },
    nombre: { type: String, required: true },
    edad: { type: Number, required: true },
    sexo: { type: String, required: true },
    fotoPersonal: { type: String },
    fechaIngreso: { type: Date, default: Date.now },
    enfermedad: { type: String, required: true },
    revisado: { type: Boolean, default: false }
});

// Exportamos el modelo para poder usarlo en otras partes del programa
module.exports = mongoose.model('Paciente', PacienteSchema);