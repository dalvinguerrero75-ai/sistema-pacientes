// routes/pacienteRoutes.js

const express = require('express');
const router = express.Router();
const pacienteController = require('../controllers/pacienteController');

// Rutas para el CRUD (Crear, Leer, Actualizar, Eliminar)
// La ruta de búsqueda va primero para evitar conflictos
router.get('/pacientes/buscar', pacienteController.buscarPacientesPersonalizada);

router.post('/pacientes', pacienteController.guardarPaciente);
router.get('/pacientes', pacienteController.obtenerPacientes);
router.get('/pacientes/:id', pacienteController.obtenerPacientePorId);
router.put('/pacientes/:id', pacienteController.actualizarPaciente);
router.delete('/pacientes/:id', pacienteController.eliminarPaciente);


module.exports = router;