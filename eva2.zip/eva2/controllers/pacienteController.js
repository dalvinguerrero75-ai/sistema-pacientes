// controllers/pacienteController.js

const Paciente = require('../models/Paciente'); // Importa el "molde" de Paciente
const validator = require('validator'); // Importa la herramienta de validación

// Función para guardar un paciente
const guardarPaciente = async (req, res) => {
    try {
        const { rut, nombre, edad, sexo, enfermedad } = req.body;

        // Validamos que los campos obligatorios no estén vacíos
        if (!validator.isLength(rut, { min: 1 }) ||
            !validator.isLength(nombre, { min: 1 }) ||
            !validator.isLength(String(edad), { min: 1 }) ||
            !validator.isLength(sexo, { min: 1 }) ||
            !validator.isLength(enfermedad, { min: 1 })) {
            return res.status(400).send({ message: 'Todos los campos son obligatorios.' });
        }

        const nuevoPaciente = new Paciente(req.body);
        await nuevoPaciente.save();
        res.status(201).send(nuevoPaciente);
    } catch (error) {
        res.status(500).send({ message: 'Error al guardar el paciente.', error });
    }
};

// Función para obtener todos los pacientes
const obtenerPacientes = async (req, res) => {
    try {
        const pacientes = await Paciente.find({});
        res.status(200).send(pacientes);
    } catch (error) {
        res.status(500).send({ message: 'Error al obtener los pacientes.', error });
    }
};

// Función para obtener un paciente por su ID
const obtenerPacientePorId = async (req, res) => {
    try {
        const paciente = await Paciente.findById(req.params.id);
        if (!paciente) {
            return res.status(404).send({ message: 'Paciente no encontrado.' });
        }
        res.status(200).send(paciente);
    } catch (error) {
        res.status(500).send({ message: 'Error al obtener el paciente.', error });
    }
};

// Función para actualizar un paciente
const actualizarPaciente = async (req, res) => {
    try {
        const { rut, nombre, edad, sexo, enfermedad } = req.body;

        if (!validator.isLength(rut, { min: 1 }) ||
            !validator.isLength(nombre, { min: 1 }) ||
            !validator.isLength(String(edad), { min: 1 }) ||
            !validator.isLength(sexo, { min: 1 }) ||
            !validator.isLength(enfermedad, { min: 1 })) {
            return res.status(400).send({ message: 'Todos los campos son obligatorios.' });
        }

        const pacienteActualizado = await Paciente.findByIdAndUpdate(req.params.id, req.body, { new: true });
        if (!pacienteActualizado) {
            return res.status(404).send({ message: 'Paciente no encontrado.' });
        }
        res.status(200).send(pacienteActualizado);
    } catch (error) {
        // Imprimimos el error completo para poder ver qué está pasando.
        console.error('Error detallado al actualizar:', error);
        res.status(500).send({ message: 'Error al actualizar el paciente.', error });
    }
};

// Función para eliminar (inhabilitar) un paciente
const eliminarPaciente = async (req, res) => {
    try {
        const pacienteEliminado = await Paciente.findByIdAndUpdate(req.params.id, { revisado: true }, { new: true });
        if (!pacienteEliminado) {
            return res.status(404).send({ message: 'Paciente no encontrado.' });
        }
        res.status(200).send({ message: 'Paciente inhabilitado correctamente.' });
    } catch (error) {
        res.status(500).send({ message: 'Error al eliminar el paciente.', error });
    }
};

// Función para búsqueda personalizada
const buscarPacientesPersonalizada = async (req, res) => {
    try {
        const { sexo, fechaIngreso, enfermedad } = req.query;
        const query = {};

        if (sexo) query.sexo = sexo;
        if (fechaIngreso) query.fechaIngreso = new Date(fechaIngreso);
        if (enfermedad) query.enfermedad = enfermedad;

        const pacientes = await Paciente.find(query);
        res.status(200).send(pacientes);
    } catch (error) {
        res.status(500).send({ message: 'Error en la búsqueda personalizada.', error });
    }
};

module.exports = {
    guardarPaciente,
    obtenerPacientes,
    obtenerPacientePorId,
    actualizarPaciente,
    eliminarPaciente,
    buscarPacientesPersonalizada,
};
