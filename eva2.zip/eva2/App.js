// Este archivo contiene la aplicación completa de React en un solo lugar.
// Se utilizan hooks, componentes funcionales y React Router para la navegación.

import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Link, useNavigate, useParams } from 'react-router-dom';

// Componente para la página de inicio (Home)
function Home() {
  const [pacientesRecientes, setPacientesRecientes] = useState([]);

  useEffect(() => {
    // Al cargar la página, obtenemos los últimos 5 pacientes no revisados desde el backend.
    fetch('http://localhost:3000/api/pacientes')
      .then(response => response.json())
      .then(data => {
        const pacientesActivos = data.filter(p => p.revisado === false);
        const sortedData = pacientesActivos.sort((a, b) => new Date(b.fechaIngreso) - new Date(a.fechaIngreso));
        setPacientesRecientes(sortedData.slice(0, 5));
      })
      .catch(error => console.error('Error al obtener los pacientes:', error));
  }, []);

  return (
    <div className="text-center p-6">
      <h1 className="text-4xl font-extrabold text-gray-800 mb-4">Bienvenido al Sistema de Pacientes del Hospital El Alerce</h1>
      <p className="text-gray-600 mb-6">Gestiona los registros de pacientes de forma eficiente.</p>
      <div className="flex flex-wrap justify-center gap-4">
        <Link to="/agregar" className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-full shadow-lg transition-all duration-300 transform hover:scale-105">
          Agregar Paciente
        </Link>
        <Link to="/listar" className="bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 px-6 rounded-full shadow-lg transition-all duration-300 transform hover:scale-105">
          Listar Pacientes
        </Link>
        <Link to="/busqueda-personalizada" className="bg-fuchsia-600 hover:bg-fuchsia-700 text-white font-semibold py-3 px-6 rounded-full shadow-lg transition-all duration-300 transform hover:scale-105">
          Búsqueda Avanzada
        </Link>
      </div>
      <div className="mt-8 p-4 bg-gray-50 rounded-lg">
        <h2 className="text-xl font-bold text-gray-700 mb-4">Últimos 5 Registros</h2>
        {pacientesRecientes.length > 0 ? (
          <ul className="list-disc list-inside text-left mx-auto max-w-md">
            {pacientesRecientes.map(paciente => (
              <li key={paciente._id} className="text-gray-700 mb-2">
                <Link to={`/buscar/${paciente._id}`} className="text-blue-600 hover:underline">
                  {paciente.nombre} {paciente.apellido}
                </Link>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-gray-500 italic">No hay registros recientes para mostrar.</p>
        )}
      </div>
    </div>
  );
}

// Componente para agregar un nuevo paciente (NuevoRegistro)
function NuevoRegistro() {
  const navigate = useNavigate();
  const [pacienteData, setPacienteData] = useState({
    nombre: '',
    apellido: '',
    rut: '',
    edad: '',
    sexo: '',
    enfermedad: '',
    fotoPersonal: '',
    revisado: false,
    fechaIngreso: new Date().toISOString().split('T')[0]
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setPacienteData(prevData => ({
      ...prevData,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch('http://localhost:3000/api/pacientes', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(pacienteData),
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('No se pudo agregar el paciente');
        }
        return response.json();
      })
      .then(data => {
        alert('Paciente agregado con éxito!');
        navigate('/listar'); // Redirige a la lista de pacientes
      })
      .catch(error => {
        console.error('Error al agregar el paciente:', error);
        alert('Hubo un error al agregar el paciente. Por favor, intente de nuevo.');
      });
  };

  return (
    <div className="p-6">
      <h2 className="text-3xl font-bold text-gray-800 mb-6">Nuevo Registro de Paciente</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="nombre">Nombre</label>
            <input
              type="text"
              id="nombre"
              name="nombre"
              value={pacienteData.nombre}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="apellido">Apellido</label>
            <input
              type="text"
              id="apellido"
              name="apellido"
              value={pacienteData.apellido}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="rut">RUT</label>
            <input
              type="text"
              id="rut"
              name="rut"
              value={pacienteData.rut}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="edad">Edad</label>
            <input
              type="number"
              id="edad"
              name="edad"
              value={pacienteData.edad}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="sexo">Sexo</label>
            <select
              id="sexo"
              name="sexo"
              value={pacienteData.sexo}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            >
              <option value="">Seleccione</option>
              <option value="Masculino">Masculino</option>
              <option value="Femenino">Femenino</option>
              <option value="Otro">Otro</option>
            </select>
          </div>
          <div>
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="enfermedad">Enfermedad</label>
            <input
              type="text"
              id="enfermedad"
              name="enfermedad"
              value={pacienteData.enfermedad}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="fotoPersonal">URL de la Foto</label>
            <input
              type="url"
              id="fotoPersonal"
              name="fotoPersonal"
              value={pacienteData.fotoPersonal}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
        <div className="flex items-center">
          <input
            type="checkbox"
            id="revisado"
            name="revisado"
            checked={pacienteData.revisado}
            onChange={handleChange}
            className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
          />
          <label className="ml-2 text-gray-700 font-semibold" htmlFor="revisado">Revisado</label>
        </div>
        <button
          type="submit"
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-md shadow-lg transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Agregar Paciente
        </button>
      </form>
    </div>
  );
}

// Componente para listar todos los pacientes (ListarRegistros)
function ListarRegistros() {
  const [pacientes, setPacientes] = useState([]);

  useEffect(() => {
    // Solo obtenemos los pacientes que NO están marcados como 'revisado' (eliminados)
    fetch('http://localhost:3000/api/pacientes')
      .then(response => {
        if (!response.ok) {
          throw new Error('La respuesta de la red no fue exitosa');
        }
        return response.json();
      })
      .then(data => {
        // Filtramos en el frontend solo para mostrar los que no están 'revisado'
        const pacientesActivos = data.filter(p => p.revisado === false);
        setPacientes(pacientesActivos);
      })
      .catch(error => {
        console.error('Error al obtener los pacientes:', error);
      });
  }, []);

  return (
    <div className="p-6">
      <h2 className="text-3xl font-bold text-gray-800 mb-6">Listado de Pacientes</h2>
      {pacientes.length > 0 ? (
        <div className="overflow-x-auto relative shadow-md sm:rounded-lg">
          <table className="w-full text-sm text-left text-gray-500">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50">
              <tr>
                <th scope="col" className="py-3 px-6">
                  Foto
                </th>
                <th scope="col" className="py-3 px-6">
                  Nombre Completo
                </th>
                <th scope="col" className="py-3 px-6">
                  Ver Información
                </th>
              </tr>
            </thead>
            <tbody>
              {pacientes.map(paciente => (
                <tr key={paciente._id} className="bg-white border-b hover:bg-gray-50">
                  <td className="py-4 px-6">
                    <img
                      src={paciente.fotoPersonal || `https://placehold.co/50x50/e2e8f0/64748b?text=Foto`}
                      alt={`Foto de ${paciente.nombre} ${paciente.apellido}`}
                      className="w-12 h-12 rounded-full object-cover border-2 border-gray-200"
                    />
                  </td>
                  <td className="py-4 px-6 font-medium text-gray-900 whitespace-nowrap">
                    {paciente.nombre} {paciente.apellido}
                  </td>
                  <td className="py-4 px-6">
                    <Link to={`/buscar/${paciente._id}`} className="font-medium text-blue-600 hover:underline">
                      Ver información
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="text-gray-500">No hay pacientes registrados.</p>
      )}
    </div>
  );
}

// Componente para buscar un paciente específico (BuscarRegistro)
function BuscarRegistro() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [paciente, setPaciente] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:3000/api/pacientes/${id}`)
      .then(response => {
        if (!response.ok) {
          throw new Error('No se encontró el paciente.');
        }
        return response.json();
      })
      .then(data => {
        setPaciente(data);
      })
      .catch(err => {
        console.error('Error al obtener el paciente:', err);
        setError(err.message);
      });
  }, [id]);

  const handleDelete = () => {
    // Usamos un simple cuadro de diálogo de confirmación antes de eliminar
    if (window.confirm('¿Estás seguro de que deseas eliminar este paciente?')) {
      fetch(`http://localhost:3000/api/pacientes/${id}`, {
        method: 'DELETE',
      })
        .then(response => {
          if (!response.ok) {
            throw new Error('No se pudo eliminar el paciente.');
          }
          alert('Paciente eliminado con éxito!');
          navigate('/listar'); // Redirige a la lista de pacientes
        })
        .catch(error => {
          console.error('Error al eliminar el paciente:', error);
          alert('Hubo un error al eliminar el paciente. Por favor, intente de nuevo.');
        });
    }
  };

  if (error) {
    return <div className="p-6 text-red-500 font-semibold">Error: {error}</div>;
  }

  if (!paciente) {
    return <div className="p-6 text-gray-500">Cargando...</div>;
  }

  return (
    <div className="p-6">
      <h2 className="text-3xl font-bold text-gray-800 mb-4">Información del Paciente: <span className="text-blue-600">{paciente.nombre} {paciente.apellido}</span></h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-gray-50 p-6 rounded-lg shadow-inner">
        <div className="flex justify-center items-center">
          <img src={paciente.fotoPersonal || `https://placehold.co/200x200/e2e8f0/64748b?text=Foto`} alt={`Foto de ${paciente.nombre}`} className="w-48 h-48 rounded-lg object-cover border-4 border-white shadow-md" />
        </div>
        <div>
          <p className="text-gray-700"><span className="font-bold">RUT:</span> {paciente.rut}</p>
          <p className="text-gray-700"><span className="font-bold">Edad:</span> {paciente.edad}</p>
          <p className="text-gray-700"><span className="font-bold">Sexo:</span> {paciente.sexo}</p>
          <p className="text-gray-700"><span className="font-bold">Enfermedad:</span> {paciente.enfermedad}</p>
          <p className="text-gray-700"><span className="font-bold">Fecha de Ingreso:</span> {new Date(paciente.fechaIngreso).toLocaleDateString()}</p>
          <p className="text-gray-700"><span className="font-bold">Revisado:</span> {paciente.revisado ? 'Sí' : 'No'}</p>
        </div>
      </div>
      <div className="mt-6 flex flex-col sm:flex-row gap-4">
        <Link to={`/actualizar/${paciente._id}`} className="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold py-2 px-4 rounded-full transition-all duration-300 text-center">
          Actualizar Registro
        </Link>
        <button
          onClick={handleDelete}
          className="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded-full transition-all duration-300 text-center">
          Eliminar Registro
        </button>
      </div>
    </div>
  );
}

// Componente para actualizar un paciente (ActualizarRegistro)
function ActualizarRegistro() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [pacienteData, setPacienteData] = useState({
    nombre: '',
    apellido: '',
    rut: '',
    edad: '',
    sexo: '',
    enfermedad: '',
    fotoPersonal: '',
    revisado: false,
    fechaIngreso: ''
  });
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch(`http://localhost:3000/api/pacientes/${id}`)
      .then(response => {
        if (!response.ok) {
          throw new Error('No se encontró el paciente para actualizar.');
        }
        return response.json();
      })
      .then(data => {
        const fechaFormateada = data.fechaIngreso ? new Date(data.fechaIngreso).toISOString().split('T')[0] : '';
        setPacienteData({
          ...data,
          fechaIngreso: fechaFormateada
        });
        setCargando(false);
      })
      .catch(err => {
        console.error('Error al cargar los datos del paciente:', err);
        setError(err.message);
        setCargando(false);
      });
  }, [id]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setPacienteData(prevData => ({
      ...prevData,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    fetch(`http://localhost:3000/api/pacientes/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(pacienteData),
    })
      .then(response => {
        if (!response.ok) {
          throw new Error('No se pudo actualizar el paciente.');
        }
        return response.json();
      })
      .then(data => {
        alert('Paciente actualizado con éxito!');
        navigate('/listar');
      })
      .catch(error => {
        console.error('Error al actualizar el paciente:', error);
        alert('Hubo un error al actualizar el paciente. Por favor, intente de nuevo.');
      });
  };

  if (cargando) {
    return <div className="p-6 text-gray-500">Cargando datos del paciente...</div>;
  }

  if (error) {
    return <div className="p-6 text-red-500 font-semibold">Error: {error}</div>;
  }

  return (
    <div className="p-6">
      <h2 className="text-3xl font-bold text-gray-800 mb-6">Actualizar Registro de Paciente</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="nombre">Nombre</label>
            <input
              type="text"
              id="nombre"
              name="nombre"
              value={pacienteData.nombre}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="apellido">Apellido</label>
            <input
              type="text"
              id="apellido"
              name="apellido"
              value={pacienteData.apellido}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="rut">RUT</label>
            <input
              type="text"
              id="rut"
              name="rut"
              value={pacienteData.rut}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="edad">Edad</label>
            <input
              type="number"
              id="edad"
              name="edad"
              value={pacienteData.edad}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div>
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="sexo">Sexo</label>
            <select
              id="sexo"
              name="sexo"
              value={pacienteData.sexo}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            >
              <option value="">Seleccione</option>
              <option value="Masculino">Masculino</option>
              <option value="Femenino">Femenino</option>
              <option value="Otro">Otro</option>
            </select>
          </div>
          <div>
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="enfermedad">Enfermedad</label>
            <input
              type="text"
              id="enfermedad"
              name="enfermedad"
              value={pacienteData.enfermedad}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="fotoPersonal">URL de la Foto</label>
            <input
              type="url"
              id="fotoPersonal"
              name="fotoPersonal"
              value={pacienteData.fotoPersonal}
              onChange={handleChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
        <div className="flex items-center">
          <input
            type="checkbox"
            id="revisado"
            name="revisado"
            checked={pacienteData.revisado}
            onChange={handleChange}
            className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500"
          />
          <label className="ml-2 text-gray-700 font-semibold" htmlFor="revisado">Revisado</label>
        </div>
        <button
          type="submit"
          className="w-full bg-yellow-500 hover:bg-yellow-600 text-white font-semibold py-3 px-6 rounded-md shadow-lg transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Actualizar Paciente
        </button>
      </form>
    </div>
  );
}

// Componente para búsqueda personalizada (BusquedaPersonalizada)
function BusquedaPersonalizada() {
  const [pacientes, setPacientes] = useState([]);
  const [filtros, setFiltros] = useState({
    sexo: '',
    enfermedad: '',
    fechaIngreso: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFiltros(prevFiltros => ({
      ...prevFiltros,
      [name]: value,
    }));
  };

  const handleSearch = (e) => {
    e.preventDefault();
    const params = new URLSearchParams(filtros);
    const queryString = params.toString();

    fetch(`http://localhost:3000/api/pacientes/buscar?${queryString}`)
      .then(response => {
        if (!response.ok) {
          throw new Error('Error en la búsqueda.');
        }
        return response.json();
      })
      .then(data => {
        setPacientes(data);
      })
      .catch(error => {
        console.error('Error en la búsqueda:', error);
        alert('Hubo un error al realizar la búsqueda.');
      });
  };

  return (
    <div className="p-6">
      <h2 className="text-3xl font-bold text-gray-800 mb-6">Búsqueda Avanzada de Pacientes</h2>
      <form onSubmit={handleSearch} className="space-y-4 mb-8 p-6 bg-gray-50 rounded-lg shadow-inner">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="sexo">Filtrar por Sexo</label>
            <select
              name="sexo"
              id="sexo"
              value={filtros.sexo}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Todos</option>
              <option value="Masculino">Masculino</option>
              <option value="Femenino">Femenino</option>
              <option value="Otro">Otro</option>
            </select>
          </div>
          <div>
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="enfermedad">Filtrar por Enfermedad</label>
            <input
              type="text"
              name="enfermedad"
              id="enfermedad"
              value={filtros.enfermedad}
              onChange={handleInputChange}
              placeholder="Ej: Diabetes"
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-gray-700 font-semibold mb-2" htmlFor="fechaIngreso">Filtrar por Fecha</label>
            <input
              type="date"
              name="fechaIngreso"
              id="fechaIngreso"
              value={filtros.fechaIngreso}
              onChange={handleInputChange}
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
        <button
          type="submit"
          className="w-full bg-fuchsia-600 hover:bg-fuchsia-700 text-white font-semibold py-3 px-6 rounded-md shadow-lg transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Buscar Pacientes
        </button>
      </form>

      <h3 className="text-2xl font-bold text-gray-800 mb-4">Resultados de la Búsqueda</h3>
      {pacientes.length > 0 ? (
        <div className="overflow-x-auto relative shadow-md sm:rounded-lg">
          <table className="w-full text-sm text-left text-gray-500">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50">
              <tr>
                <th scope="col" className="py-3 px-6">
                  Foto
                </th>
                <th scope="col" className="py-3 px-6">
                  Nombre Completo
                </th>
                <th scope="col" className="py-3 px-6">
                  Ver Información
                </th>
              </tr>
            </thead>
            <tbody>
              {pacientes.map(paciente => (
                <tr key={paciente._id} className="bg-white border-b hover:bg-gray-50">
                  <td className="py-4 px-6">
                    <img
                      src={paciente.fotoPersonal || `https://placehold.co/50x50/e2e8f0/64748b?text=Foto`}
                      alt={`Foto de ${paciente.nombre} ${paciente.apellido}`}
                      className="w-12 h-12 rounded-full object-cover border-2 border-gray-200"
                    />
                  </td>
                  <td className="py-4 px-6 font-medium text-gray-900 whitespace-nowrap">
                    {paciente.nombre} {paciente.apellido}
                  </td>
                  <td className="py-4 px-6">
                    <Link to={`/buscar/${paciente._id}`} className="font-medium text-blue-600 hover:underline">
                      Ver información
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="text-gray-500 italic">No se encontraron resultados. Intenta ajustar los filtros.</p>
      )}
    </div>
  );
}

// --------------------------------------------------------------------------------
//  Componente principal de la aplicación (App)
//  --------------------------------------------------------------------------------
function App() {
  const [searchId, setSearchId] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchId) {
      navigate(`/buscar/${searchId}`);
    }
  };

  return (
    <div className="bg-gray-100 min-h-screen font-sans antialiased flex flex-col items-center p-8">
      {/* Menú de Navegación */}
      <nav className="bg-white p-4 rounded-full shadow-lg mb-8 w-full max-w-4xl flex justify-between items-center flex-wrap">
        <ul className="flex space-x-4">
          <li>
            <Link to="/" className="text-gray-600 hover:text-blue-600 font-medium transition-colors duration-300">Inicio</Link>
          </li>
          <li>
            <Link to="/agregar" className="text-gray-600 hover:text-blue-600 font-medium transition-colors duration-300">Agregar Paciente</Link>
          </li>
          <li>
            <Link to="/listar" className="text-gray-600 hover:text-blue-600 font-medium transition-colors duration-300">Listar Pacientes</Link>
          </li>
        </ul>
        <form onSubmit={handleSearch} className="flex items-center space-x-2">
          <input
            type="text"
            placeholder="Buscar por ID..."
            value={searchId}
            onChange={(e) => setSearchId(e.target.value)}
            className="p-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all duration-300"
          />
          <button type="submit" className="bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 transition-all duration-300">
            Buscar
          </button>
        </form>
      </nav>

      {/* Área de Contenido Principal */}
      <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-4xl">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/agregar" element={<NuevoRegistro />} />
          <Route path="/listar" element={<ListarRegistros />} />
          <Route path="/buscar/:id" element={<BuscarRegistro />} />
          <Route path="/actualizar/:id" element={<ActualizarRegistro />} />
          <Route path="/busqueda-personalizada" element={<BusquedaPersonalizada />} />
        </Routes>
      </div>
    </div>
  );
}

// --------------------------------------------------------------------------------
//  Componente Wrapper para Router y Exportación
//  --------------------------------------------------------------------------------
// Este es el componente que se exporta y contiene el Router.
function AppWrapper() {
  return (
    <BrowserRouter>
      <App />
    </BrowserRouter>
  );
}

export default AppWrapper;